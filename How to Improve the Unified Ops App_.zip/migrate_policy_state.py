#!/usr/bin/env python3
"""Migrate Unified Ops AX policy state from SQLite to PostgreSQL.

Usage:
  python scripts/migrate_policy_state.py \
    --sqlite data/policy_state.db \
    --postgresql "$DATABASE_URL"

Dry-run validation:
  python scripts/migrate_policy_state.py \
    --sqlite data/policy_state.db \
    --postgresql "$DATABASE_URL" \
    --dry-run

Requires psycopg 3:
  python -m pip install "psycopg[binary]>=3.1"

The script migrates only the DurablePolicyEngine state tables. High-volume raw
telemetry should be migrated through the telemetry system, not this utility.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
from dataclasses import dataclass
from typing import Any

import psycopg
from psycopg.rows import dict_row


SCHEMA = """
CREATE TABLE IF NOT EXISTS processed_alerts (
    alert_id TEXT PRIMARY KEY,
    accepted_at DOUBLE PRECISION NOT NULL
);

CREATE TABLE IF NOT EXISTS active_override (
    singleton SMALLINT PRIMARY KEY CHECK (singleton = 1),
    payload_json JSONB NOT NULL,
    expires_at DOUBLE PRECISION NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    event_type TEXT NOT NULL,
    event_json JSONB NOT NULL,
    created_at DOUBLE PRECISION NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_log_created_at
    ON audit_log (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_audit_log_type_created
    ON audit_log (event_type, created_at DESC);
"""


@dataclass
class Counts:
    processed_alerts: int
    active_override: int
    audit_log: int


def sqlite_counts(db: sqlite3.Connection) -> Counts:
    def count(table: str) -> int:
        return int(db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])

    return Counts(
        processed_alerts=count("processed_alerts"),
        active_override=count("active_override"),
        audit_log=count("audit_log"),
    )


def postgres_counts(conn: psycopg.Connection) -> Counts:
    with conn.cursor() as cur:
        def count(table: str) -> int:
            cur.execute(f"SELECT COUNT(*) FROM {table}")
            return int(cur.fetchone()[0])

        return Counts(
            processed_alerts=count("processed_alerts"),
            active_override=count("active_override"),
            audit_log=count("audit_log"),
        )


def validate_sqlite_schema(db: sqlite3.Connection) -> None:
    expected = {"processed_alerts", "active_override", "audit_log"}
    actual = {
        row[0]
        for row in db.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
    }
    missing = expected - actual
    if missing:
        raise RuntimeError(f"SQLite database is missing tables: {sorted(missing)}")


def migrate(sqlite_path: str, postgres_url: str, dry_run: bool = False) -> None:
    sqlite_db = sqlite3.connect(sqlite_path)
    sqlite_db.row_factory = sqlite3.Row
    try:
        validate_sqlite_schema(sqlite_db)
        source_counts = sqlite_counts(sqlite_db)

        with psycopg.connect(postgres_url, row_factory=dict_row) as pg:
            with pg.cursor() as cur:
                cur.execute(SCHEMA)
            pg.commit()

            if dry_run:
                target_counts = postgres_counts(pg)
                print(f"SQLite source counts: {source_counts}")
                print(f"PostgreSQL existing counts: {target_counts}")
                print("Dry run complete; no rows imported.")
                return

            # A single PostgreSQL transaction makes the import all-or-nothing.
            with pg.transaction():
                with pg.cursor() as cur:
                    cur.execute("TRUNCATE processed_alerts, active_override, audit_log RESTART IDENTITY")

                    cur.executemany(
                        "INSERT INTO processed_alerts(alert_id, accepted_at) VALUES (%s, %s)",
                        [
                            (row["alert_id"], row["accepted_at"])
                            for row in sqlite_db.execute(
                                "SELECT alert_id, accepted_at FROM processed_alerts"
                            )
                        ],
                    )

                    override_rows = list(
                        sqlite_db.execute(
                            "SELECT singleton, payload_json, expires_at FROM active_override"
                        )
                    )
                    for row in override_rows:
                        payload = row["payload_json"]
                        if isinstance(payload, str):
                            payload = json.loads(payload)
                        cur.execute(
                            "INSERT INTO active_override(singleton, payload_json, expires_at) "
                            "VALUES (%s, %s, %s)",
                            (row["singleton"], json.dumps(payload), row["expires_at"]),
                        )

                    cur.executemany(
                        "INSERT INTO audit_log(event_type, event_json, created_at) "
                        "VALUES (%s, %s, %s)",
                        [
                            (
                                row["event_type"],
                                json.dumps(json.loads(row["event_json"]))
                                if isinstance(row["event_json"], str)
                                else json.dumps(row["event_json"]),
                                row["created_at"],
                            )
                            for row in sqlite_db.execute(
                                "SELECT event_type, event_json, created_at "
                                "FROM audit_log ORDER BY id"
                            )
                        ],
                    )

            target_counts = postgres_counts(pg)
            if source_counts != target_counts:
                raise RuntimeError(
                    f"Count verification failed: source={source_counts}, target={target_counts}"
                )

        print(f"Migration complete and verified: {source_counts}")
    finally:
        sqlite_db.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sqlite", required=True, help="Path to SQLite policy-state database")
    parser.add_argument("--postgresql", required=True, help="PostgreSQL DSN or DATABASE_URL")
    parser.add_argument("--dry-run", action="store_true", help="Validate source/schema and show counts only")
    args = parser.parse_args()

    try:
        migrate(args.sqlite, args.postgresql, args.dry_run)
    except Exception as exc:
        print(f"Migration failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
