# SQLite-backed DurablePolicyEngine: Test Suite and Alert-Storm Analysis

## Scope and assumptions

The attached pytest module is designed for the prototype architecture proposed earlier. It assumes that `PolicyStateStore` is available from `policy_state_store.py`, that `DurablePolicyEngine` accepts `state_store=...`, and that the engine exposes `recover()` to rehydrate an unexpired override after restart.

The suite intentionally tests both **state-machine semantics** and **storage semantics**. It covers idempotency, replay protection, policy precedence, persistence, restart recovery, expiry, rollback, audit durability, multiple connections, exact threshold behavior, and concurrent duplicate alerts.

The test module is syntactically valid. It should be run from the repository root after installing the project dependencies and pytest:

```bash
python -m pip install -r requirements.txt pytest
pytest -q tests/test_sqlite_policy_state.py
```

## Test inventory

| Test area | Tests | Primary invariant |
|---|---:|---|
| Schema and configuration | 1 | SQLite database initializes with WAL and required tables. |
| Idempotency | 2 | An alert ID can be claimed only once, including after restart. |
| Persistence and recovery | 3 | Active policy state and rollback token survive process restart. |
| Expiry | 1 | Expired policy state is removed during recovery. |
| Precedence | 1 | A lower-priority alert cannot overwrite an active higher-priority policy. |
| Rollback | 2 | Valid rollback clears persisted state; invalid tokens do not mutate state. |
| Replay protection | 1 | Stale webhook timestamps are rejected before claiming an alert. |
| Concurrency | 3 | Duplicate storms produce one acceptance; distinct alerts do not create duplicate claims. |
| Audit durability | 1 | Applied and rolled-back events remain after restart. |
| Boundary behavior | 1 | Policies fire at their exact configured thresholds. |

The most important test is `test_concurrent_duplicate_alerts_accept_exactly_one`. It models multiple application workers receiving the same upstream alert and verifies that the database—not process-local memory—decides which request wins.

## Important implementation caveat

The prototype should make **claiming an alert and applying the policy** part of one state-machine transition. If the engine claims an alert and then loses the process before the override/audit write, the alert is permanently considered processed even though remediation did not complete. A production-quality version should use an alert table with explicit states such as `RECEIVED`, `CLAIMED`, `APPLIED`, `FAILED`, and `RETRYABLE`, or use one SQLite transaction that inserts the claim and writes the audit/override record together.

Similarly, a lower-priority alert should normally be recorded as `precedence_blocked` rather than silently discarded. That gives operators an explanation and preserves evidence of the incident storm.

## Likely bottlenecks under high-concurrency alert storms

SQLite is attractive for a single-node prototype because it is embedded and transactional. However, its concurrency model still matters: SQLite allows multiple readers but only one simultaneous writer, even when using WAL mode.[1] The application can therefore encounter contention even if every request opens its own connection.

| Bottleneck | What happens during an alert storm | Observable symptom | Mitigation |
|---|---|---|---|
| Single-writer serialization | Every alert claims an ID, writes an override, and appends an audit row. Those writes queue behind one writer. | Rising commit latency, `database is locked`, or request timeouts. | Keep transactions short; use WAL; configure `busy_timeout`; batch audit writes; move high-volume telemetry out of SQLite. |
| Check-then-write race | Separate “does this alert exist?” and “insert alert” operations can both pass before either inserts. | Duplicate remediation or inconsistent counters. | Use a single atomic `INSERT ... ON CONFLICT` or `INSERT OR IGNORE` and inspect `rowcount`. |
| Oversized critical section | Holding a Python lock while doing policy execution, network notification, or telemetry emission blocks unrelated alerts. | Low throughput despite low database CPU. | Lock only state transitions; enqueue external side effects after commit. |
| Per-operation connection setup | Opening/configuring a new connection for every small read and write adds file and PRAGMA overhead. | High CPU/syscall overhead and long-tail latency. | Use a thread-local connection or bounded connection pool; configure each connection once. |
| Audit-log growth | One row per alert can grow quickly and make counts or history queries slower. | Larger database, slower dashboards, growing WAL file. | Index by `created_at`, archive old audit rows, checkpoint periodically, and use a separate event sink for raw telemetry. |
| Checkpoint stalls | WAL mode permits readers and writers to overlap, but checkpoints must copy WAL pages back into the main database. Long readers can delay checkpoints.[1] | Periodic latency spikes; WAL file growth. | Keep read transactions short; schedule passive or incremental checkpoints; monitor WAL size. |
| Multi-process filesystem limits | WAL requires cooperating processes on the same host and is not appropriate for a network filesystem.[1] | Locking failures or unsupported deployment behavior on shared volumes. | Use SQLite only for one host; use Postgres/Redis for multi-replica deployment. |
| Streamlit process lifecycle | Streamlit reruns and ephemeral deployment restarts can create multiple engine instances or lose local files. | State appears to reset; cooldowns disappear. | Put state in a stable mounted volume for the prototype, or use a managed database for deployment. |
| Unbounded deduplication state | A Python set or table of every alert ID grows without retention. | Memory or database growth over time. | Add a retention policy, partition/archive old IDs, or retain a digest window appropriate to the upstream replay window. |
| Hot singleton override row | Every policy update contends on the same `active_override` row. | Latency rises when many anomaly types arrive together. | Use an append-only event log plus a materialized active-state projection, or serialize policy decisions through one worker. |
| Side-effect coupling | Remediation waits synchronously for K8s, Slack, Splunk, or email calls. | Database transaction remains open while external services are slow. | Commit intent first, execute side effects asynchronously, then record verification/failure. |

## SQLite tuning recommendations

### Use WAL, but understand what it solves

WAL is a good default for this prototype because readers can proceed while a writer appends changes, but there is still only one writer at a time.[1] Keep the connection setup explicit:

```python
conn = sqlite3.connect(
    path,
    timeout=10.0,
    isolation_level=None,
    check_same_thread=False,
)
conn.execute("PRAGMA journal_mode=WAL")
conn.execute("PRAGMA synchronous=NORMAL")
conn.execute("PRAGMA busy_timeout=10000")
conn.execute("PRAGMA foreign_keys=ON")
conn.execute("PRAGMA wal_autocheckpoint=1000")
```

` synchronous=NORMAL` is a throughput-oriented choice and should be documented as a durability trade-off. Use `FULL` when the audit record must survive a power loss at the cost of more sync work. The SQLite documentation notes that WAL improves reader/writer concurrency but still has checkpointing and one-writer constraints.[1]

### Use one short `BEGIN IMMEDIATE` transaction for the state transition

SQLite documents that `BEGIN IMMEDIATE` starts a write transaction immediately and can fail with `SQLITE_BUSY` if another writer is active.[2] For the critical transition, that behavior is preferable to discovering contention halfway through a multi-step operation.

A store-level method should own the transaction:

```python
def claim_and_record_policy(self, alert_id, accepted_at, override_payload, audit_payload):
    with self._connect() as db:
        db.execute("BEGIN IMMEDIATE")
        try:
            inserted = db.execute(
                "INSERT INTO processed_alerts(alert_id, accepted_at) VALUES (?, ?)",
                (alert_id, accepted_at),
            ).rowcount
            if inserted != 1:
                db.execute("ROLLBACK")
                return False

            db.execute(
                "INSERT INTO active_override(singleton, payload_json, expires_at) "
                "VALUES (1, ?, ?) "
                "ON CONFLICT(singleton) DO UPDATE SET "
                "payload_json=excluded.payload_json, expires_at=excluded.expires_at",
                (json.dumps(override_payload), override_payload["expires_at"]),
            )
            db.execute(
                "INSERT INTO audit_log(event_type, event_json, created_at) VALUES (?, ?, ?)",
                ("policy_applied", json.dumps(audit_payload), accepted_at),
            )
            db.execute("COMMIT")
            return True
        except Exception:
            db.execute("ROLLBACK")
            raise
```

The transaction should contain only local SQLite operations. Do not call network services, sleep for cooldowns, or run model inference while the write transaction is open.

### Prefer atomic SQL over Python-level existence checks

The Python `sqlite3` documentation notes that connections have a timeout for locked tables and that cross-thread use must be deliberately managed.[3] Use a unique primary key and let SQLite arbitrate duplicates. Avoid this pattern:

```python
if not exists(alert_id):
    insert(alert_id)
```

Use `INSERT ... ON CONFLICT` or `INSERT OR IGNORE` instead. This is both faster and correct under concurrency.

### Separate hot-path state from high-volume history

The alert claim and active override are hot-path records. Detailed audit history is append-only and can be written asynchronously after the policy intent is committed, provided the system records a durable `policy_intent` first. Raw telemetry, per-token events, and debug traces should not share this SQLite file. Send those to Splunk, a log sink, or a separate analytics store.

### Index only the queries that matter

The primary key on `processed_alerts.alert_id` already supports idempotency lookup. Add an index for audit timeline queries:

```sql
CREATE INDEX IF NOT EXISTS idx_audit_log_created_at
ON audit_log(created_at DESC);
```

If the UI filters by event type, add a composite index only after measuring the query pattern:

```sql
CREATE INDEX IF NOT EXISTS idx_audit_log_type_created
ON audit_log(event_type, created_at DESC);
```

Avoid indexing every JSON field. If the dashboard frequently filters by anomaly type or status, promote those values into typed columns rather than querying JSON text.

### Control WAL growth and retention

WAL mode requires checkpointing. SQLite documents that automatic checkpoints occur at a page threshold and that long-running readers can prevent checkpoint progress.[1] Keep dashboard reads short and explicitly checkpoint during low-load periods:

```python
# Run from a maintenance thread or scheduled task, not inside the alert transaction.
with store._connect() as db:
    db.execute("PRAGMA wal_checkpoint(PASSIVE)")
```

Do not run `VACUUM` during an alert storm. Archive or delete old audit rows in small batches, then run maintenance during a quiet period.

## When to move beyond SQLite

SQLite is sufficient for a single-process or single-host hackathon prototype, especially when the main goal is demonstrating durable state and deterministic behavior. Move the store to Postgres or another server-backed system when the app requires multiple Streamlit/FastAPI replicas, cross-host failover, high write rates, long-lived audit retention, tenant isolation, or transactional coordination with other services. WAL does not turn SQLite into a multi-writer distributed database; SQLite’s own documentation states that only one writer can operate at a time and that WAL relies on same-host shared memory.[1] [2]

A practical migration boundary is reached when sustained alert traffic causes queueing rather than policy execution to dominate latency, when the WAL file repeatedly grows faster than checkpoints can drain it, or when operational correctness requires a database-backed lease and worker coordination across hosts.

## Recommended alert-storm architecture

The strongest production-shaped design is a two-stage pipeline. A lightweight ingress handler validates the webhook, deduplicates the alert atomically, and commits a small policy-intent record. A single policy coordinator or partitioned worker then evaluates precedence and applies the remediation. External side effects run asynchronously and report verification events back into the audit log.

This structure prevents a burst of 1,000 duplicate alerts from launching 1,000 remediation jobs. It also gives the system a natural place to coalesce alerts—for example, one active `cost_spike` incident per model and region per five-minute window—while preserving the count of suppressed duplicates for audit and metrics.

## Final recommendation

Use the attached suite as the acceptance gate for the SQLite prototype, but add one implementation change before running it: combine alert claiming, precedence evaluation, override persistence, and the initial audit record into a single store-owned transaction. Then load-test with 16, 64, and 256 concurrent callers using both duplicate and distinct alert IDs. Record acceptance rate, rejection rate, p50/p95/p99 latency, SQLite busy retries, WAL size, and audit-row count. Those measurements will tell you whether SQLite remains an appropriate demo backend or whether the architecture is ready for a server-backed store.

## References

[1]: https://www.sqlite.org/wal.html "SQLite Write-Ahead Logging"

[2]: https://www.sqlite.org/lang_transaction.html "SQLite Transactions"

[3]: https://docs.python.org/3/library/sqlite3.html "Python sqlite3 module documentation"
