# Unified Ops AX review notes

## Devpost claims
- Product: AI-powered autonomous fleet telemetry and asynchronous remediation engine for AI agent fleets.
- Features claimed: AsyncAgentEngine priority queue; 1,000+ telemetry events/batch; real-time Splunk HEC telemetry; event-driven remediation for cost, latency, and DLP anomalies.
- Stack claimed: Python 3.11, asyncio.PriorityQueue, Google ADK, Splunk HEC, multi-LLM router, Context7, vector RAG, FastAPI.
- Outcomes claimed: >31 tasks/sec, 1,000 telemetry events in 0.317s, sub-10ms auto-remediation, 17/17 tests passed on Devpost; README later claims 25 tests.
- Next steps claimed: Kafka/GCP Pub/Sub streaming, Kubernetes HPA integration, local DLP models, enterprise dashboards.

## Repository findings
- GitHub repo created Aug 24, 2026, one commit, Apache-2.0, 0 stars/forks at review time.
- Top-level structure includes streamlit_app.py, demo_app.py, async_agent_engine.py, auto_remediation.py, local_dlp_guardrail.py, pubsub_kafka_stream_processor.py, splunk_app, security, tests, docs, Dockerfile, docker-compose.yml.
- README presents a Splunk closed-loop architecture: agent telemetry -> Splunk HEC -> anomaly detection/webhook -> remediation; DLP -> SOAR; NL-to-SPL via Splunk MCP.
- streamlit_app.py is a 5-view control center: 3D map, async workers/task submission, K8s replica simulation, DLP masking playground, Prometheus metrics exposition.
- streamlit_app.py initializes AsyncAgentEngine(num_workers=4) in session state via asyncio.run(engine.start()). It uses hard-coded map data and displays hard-coded/derived demo values including 3 regions, 2,000 logs, and PyDeck nodes.
- K8s page calls a local autoscaler object and labels manual action as 'Apply kubectl scale deployment' although implementation appears simulator-oriented.
- DLP page provides sample SSN/card/email/API-key text and displays masked text/rules/hash after inspection.
- auto_remediation.py defines policies for cost, latency, error rate, DLP burst, token overrun. Several actions are simulated/logged rather than integrated: notify uses logger only; caching, max tokens, circuit breaker, and DLP strictness return descriptive strings. Router weight restore uses a daemon thread sleeping for cooldown.
- demo_app.py is a large second Streamlit experience with generated demo data and a 'Demo Mode' concept; there are multiple alternate app URLs in repo/README, creating possible product identity confusion.

## Live app findings
- Live deployment loaded at https://unified-ops.streamlit.app/.
- Title: Unified Ops AX: Fleet Control Center.
- First screen shows sidebar with unrelated Streamlit apps/links above Unified Ops AX, then five navigation choices.
- Global map screen rendered successfully with dark theme, KPI cards, and PyDeck map.
- Visible KPIs at first load: Active Regions 3 Monitored; Queue Throughput 0.0 tasks/s; K8s Replicas 2 pods; Total Tasks Processed 0 tasks. This is more honest/dynamic than some README/demo claims but can make the app look inactive.
- Map visual renders arcs and points but does not visibly present a legend, event timeline, health explanation, or strong drill-down affordance in initial view.
- The Streamlit page displays external app navigation items ('Recommender', 'EDA Pipeline', 'Churn Classifier', 'Sales Forecast', 'Sentiment Analyzer') above the app branding, which dilutes focus and may be an environment-level presentation issue.
- Need further interaction testing of each view and controls if possible.

## Initial hypotheses for improvements
- Clarify product scope and primary persona; unify app names/URLs and distinguish live vs simulator/demo mode.
- Replace hard-coded/demo metrics with clearly labeled synthetic data or real backend state, timestamps, and data freshness indicators.
- Make remediation actions verifiably executable, auditable, reversible, and approval-gated for production use.
- Improve observability UX: alert severity, current incidents, action history, policy state, cooldown countdown, before/after impact, and drill-down.
- Improve architecture/code quality: one canonical Streamlit entry point, reproducible CI, tests aligned with claims, persistent/shared state, robust async lifecycle, authentication/authorization, webhook replay protection/idempotency, structured logging, and real integrations.
- Fix claim consistency: Devpost says 17 tests while README says 25; 'under 10 ms' needs benchmark methodology and environment; 'fine-tuned local DLP' appears inconsistent with regex-style guardrail implementation in visible app code.

Review is ongoing; do not treat these notes as final without interaction and synthesis.

## Live interaction findings
- Async Engine view initially showed RUNNING, 4 threads, 0 processed tasks, and queue counts all zero.
- Controls rendered correctly after a wait: batch volume slider (100–2,000, default 500), priority selector, enqueue button, anomaly selector, metric input, trigger button.
- Clicking 'Enqueue Batch Ingest Job' changed processed tasks from 0 to 1 and completed queue count from 0 to 1, but no visible task history, duration, throughput detail, or event trace appeared.
- Clicking 'Trigger Auto-Remediation Policy' with COST_SPIKE and metric value 8.50 incremented processed tasks to 2; no clear visible success/warning detail or action-by-action remediation result was exposed in the extracted page after rerender. This suggests feedback may be transient or visually easy to miss.
- UI wording ('Apply kubectl scale deployment') and control affordances imply production operations, while code indicates simulator/placeholder behavior in several actions; this should be made explicit to avoid misleading users.

## Additional live interaction findings
- DLP view loads with default sample content and clearly shows the input area plus an 'Inspect & Mask PII Payload' button.
- Running the default sample detected SSN, KR_RRN, API_KEY, and CREDIT_CARD; the UI displayed violation status, restricted sensitivity, an HMAC data hash, matched rules, and a masked output area. This is a strong demo interaction, but the top KPI counters still showed 0 inspections / 0 blocked before rerender, so persistence and metric refresh semantics should be made clearer.
- K8s view explicitly displays 'SIMULATED HPA' and 'Scale Deployment Replicas (SIMULATED HPA)', which is good, but the button text still says 'Apply kubectl scale deployment'. The deployment name is truncated in the metric card and the page does not yet show a real cluster connection, authorization state, or a detailed event history.
