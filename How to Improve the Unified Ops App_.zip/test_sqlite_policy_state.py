"""Tests for the SQLite-backed DurablePolicyEngine prototype.

These tests assume the implementation from unified_ops_ax_patch_and_demo.md:
- PolicyStateStore lives in policy_state_store.py.
- DurablePolicyEngine accepts state_store=PolicyStateStore(...).
- DurablePolicyEngine.recover() rehydrates an active override.
- Alert claiming is atomic and persisted by the store.
"""

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sqlite3
import threading
import time

import pytest

from auto_remediation import AnomalyType, DurablePolicyEngine
from policy_state_store import PolicyStateStore


@pytest.fixture
def db_path(tmp_path: Path) -> Path:
    """Return an isolated SQLite database path for each test."""
    return tmp_path / "policy_state.db"


@pytest.fixture
def store(db_path: Path) -> PolicyStateStore:
    return PolicyStateStore(str(db_path))


@pytest.fixture
def engine(store: PolicyStateStore) -> DurablePolicyEngine:
    return DurablePolicyEngine(state_store=store)


def test_store_initializes_wal_schema(db_path: Path):
    store = PolicyStateStore(str(db_path))

    assert db_path.exists()
    with sqlite3.connect(db_path) as db:
        journal_mode = db.execute("PRAGMA journal_mode").fetchone()[0]
        tables = {
            row[0]
            for row in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }

    assert str(journal_mode).lower() == "wal"
    assert {"processed_alerts", "active_override", "audit_log"}.issubset(tables)
    assert store.audit_count() == 0


def test_claim_alert_is_idempotent(store: PolicyStateStore):
    now = time.time()

    assert store.claim_alert("alert-1", now) is True
    assert store.claim_alert("alert-1", now) is False
    assert store.claim_alert("alert-2", now) is True


def test_apply_persists_override_and_audit(engine: DurablePolicyEngine, store: PolicyStateStore):
    now = time.time()

    result = engine.apply_remediation(
        AnomalyType.COST_SPIKE,
        metric_value=8.5,
        alert_id="cost-1",
        timestamp=now,
        owner="test-operator",
    )

    assert result["success"] is True
    assert result["status"] == "policy_applied"
    assert result["alert_id"] == "cost-1"
    assert result["rollback_token"]

    persisted = store.load_active_override(time.time())
    assert persisted is not None
    assert persisted["override_id"] == "cost-1"
    assert persisted["owner"] == "test-operator"
    assert persisted["anomaly_type"] == AnomalyType.COST_SPIKE.value
    assert persisted["active_weights"]["cost_weight"] > persisted["baseline_weights"]["cost_weight"]
    assert store.audit_count() == 1


def test_duplicate_alert_is_rejected_after_new_engine_instance(db_path: Path):
    first = DurablePolicyEngine(state_store=PolicyStateStore(str(db_path)))
    timestamp = time.time()

    accepted = first.apply_remediation(
        AnomalyType.COST_SPIKE,
        8.5,
        alert_id="duplicate-1",
        timestamp=timestamp,
    )
    assert accepted["success"] is True

    second = DurablePolicyEngine(state_store=PolicyStateStore(str(db_path)))
    duplicate = second.apply_remediation(
        AnomalyType.COST_SPIKE,
        8.5,
        alert_id="duplicate-1",
        timestamp=time.time(),
    )

    assert duplicate["success"] is False
    assert duplicate["status"] == "rejected"
    assert "Idempotency rejected" in duplicate["reason"]


def test_recover_rehydrates_active_override_after_restart(db_path: Path):
    first = DurablePolicyEngine(state_store=PolicyStateStore(str(db_path)))
    applied = first.apply_remediation(
        AnomalyType.COST_SPIKE,
        8.5,
        alert_id="restart-1",
        timestamp=time.time(),
        owner="system",
    )

    second = DurablePolicyEngine(state_store=PolicyStateStore(str(db_path)))
    assert second.active_override is None
    second.recover()

    status = second.get_status()
    assert status["active_override"] is not None
    assert status["active_override"]["policy"] == AnomalyType.COST_SPIKE.value
    assert status["active_override"]["rollback_token"] == applied["rollback_token"]
    assert status["active_override"]["active_weights"] == applied["active_weights"]


def test_expired_override_is_removed_on_recovery(db_path: Path):
    engine = DurablePolicyEngine(state_store=PolicyStateStore(str(db_path)))
    applied = engine.apply_remediation(
        AnomalyType.COST_SPIKE,
        8.5,
        alert_id="expiry-1",
        timestamp=time.time(),
    )

    # Force expiry in the persisted row without sleeping for the policy cooldown.
    with sqlite3.connect(db_path) as db:
        db.execute(
            "UPDATE active_override SET expires_at = ?, payload_json = "
            "json_set(payload_json, '$.expires_at', ?)",
            (time.time() - 1, time.time() - 1),
        )

    restarted = DurablePolicyEngine(state_store=PolicyStateStore(str(db_path)))
    restarted.recover()

    assert restarted.get_status()["active_override"] is None
    assert restarted.state_store.load_active_override(time.time()) is None
    assert applied["rollback_token"]


def test_precedence_blocks_lower_priority_without_overwriting_active_policy(
    engine: DurablePolicyEngine,
):
    critical = engine.apply_remediation(
        AnomalyType.DLP_BURST,
        15.0,
        alert_id="dlp-1",
        timestamp=time.time(),
    )
    assert critical["success"] is True

    lower_priority = engine.apply_remediation(
        AnomalyType.COST_SPIKE,
        8.5,
        alert_id="cost-while-dlp-1",
        timestamp=time.time(),
    )

    assert lower_priority["success"] is False
    assert lower_priority["status"] == "precedence_blocked"
    assert engine.get_status()["active_override"]["policy"] == AnomalyType.DLP_BURST.value


def test_rollback_clears_persisted_override_and_writes_audit(
    engine: DurablePolicyEngine, store: PolicyStateStore
):
    applied = engine.apply_remediation(
        AnomalyType.COST_SPIKE,
        8.5,
        alert_id="rollback-1",
        timestamp=time.time(),
    )

    result = engine.rollback_override(applied["rollback_token"])

    assert result["success"] is True
    assert result["status"] == "rolled_back"
    assert engine.get_status()["active_override"] is None
    assert store.load_active_override(time.time()) is None
    assert store.audit_count() == 2


def test_invalid_rollback_token_does_not_change_state(engine: DurablePolicyEngine):
    applied = engine.apply_remediation(
        AnomalyType.COST_SPIKE,
        8.5,
        alert_id="rollback-invalid-1",
        timestamp=time.time(),
    )

    result = engine.rollback_override("not-the-token")

    assert result["success"] is False
    assert result["reason"] == "Invalid rollback token"
    assert engine.get_status()["active_override"]["rollback_token"] == applied["rollback_token"]


def test_stale_webhook_is_rejected_without_claiming_alert(engine: DurablePolicyEngine):
    stale_id = "stale-1"
    result = engine.apply_remediation(
        AnomalyType.COST_SPIKE,
        8.5,
        alert_id=stale_id,
        timestamp=time.time() - 301,
    )

    assert result["success"] is False
    assert result["status"] == "rejected"
    assert "Replay rejected" in result["reason"]
    assert engine.state_store.claim_alert(stale_id, time.time()) is True


def test_concurrent_duplicate_alerts_accept_exactly_one(db_path: Path):
    shared_store = PolicyStateStore(str(db_path))
    engines = [
        DurablePolicyEngine(state_store=shared_store)
        for _ in range(16)
    ]
    barrier = threading.Barrier(len(engines))

    def submit(engine: DurablePolicyEngine):
        barrier.wait(timeout=5)
        return engine.apply_remediation(
            AnomalyType.COST_SPIKE,
            8.5,
            alert_id="storm-duplicate-1",
            timestamp=time.time(),
        )

    with ThreadPoolExecutor(max_workers=len(engines)) as pool:
        results = list(pool.map(submit, engines))

    accepted = [r for r in results if r.get("status") == "policy_applied"]
    rejected = [r for r in results if r.get("status") == "rejected"]

    assert len(accepted) == 1
    assert len(rejected) == len(engines) - 1
    assert shared_store.audit_count() == 1


def test_concurrent_distinct_alerts_do_not_duplicate_alert_ids(db_path: Path):
    shared_store = PolicyStateStore(str(db_path))
    engines = [
        DurablePolicyEngine(state_store=shared_store)
        for _ in range(12)
    ]

    def submit(index: int):
        return engines[index].apply_remediation(
            AnomalyType.COST_SPIKE,
            8.5,
            alert_id=f"storm-distinct-{index}",
            timestamp=time.time(),
        )

    with ThreadPoolExecutor(max_workers=len(engines)) as pool:
        results = list(pool.map(submit, range(len(engines))))

    # The exact number of accepted policies depends on precedence timing, but
    # each alert ID must be claimed at most once and every accepted alert has one audit row.
    assert all(result["status"] in {"policy_applied", "precedence_blocked"} for result in results)
    assert shared_store.audit_count() == sum(
        result["status"] == "policy_applied" for result in results
    )


def test_audit_log_survives_restart(db_path: Path):
    first = DurablePolicyEngine(state_store=PolicyStateStore(str(db_path)))
    applied = first.apply_remediation(
        AnomalyType.COST_SPIKE,
        8.5,
        alert_id="audit-1",
        timestamp=time.time(),
    )
    first.rollback_override(applied["rollback_token"])

    restarted_store = PolicyStateStore(str(db_path))
    assert restarted_store.audit_count() == 2


def test_store_handles_multiple_connections(db_path: Path):
    stores = [PolicyStateStore(str(db_path)) for _ in range(8)]

    def claim(index: int):
        return stores[index].claim_alert(f"connection-{index}", time.time())

    with ThreadPoolExecutor(max_workers=len(stores)) as pool:
        results = list(pool.map(claim, range(len(stores))))

    assert results == [True] * len(stores)


@pytest.mark.parametrize(
    ("anomaly_type", "metric_value"),
    [
        (AnomalyType.COST_SPIKE, 5.0),
        (AnomalyType.LATENCY_SPIKE, 5000.0),
        (AnomalyType.DLP_BURST, 10.0),
    ],
)
def test_policy_triggers_at_exact_threshold(
    engine: DurablePolicyEngine,
    anomaly_type: AnomalyType,
    metric_value: float,
):
    result = engine.apply_remediation(
        anomaly_type,
        metric_value,
        alert_id=f"threshold-{anomaly_type.value}",
        timestamp=time.time(),
    )

    assert result["success"] is True
    assert result["status"] == "policy_applied"
