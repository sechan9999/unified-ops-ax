# Unified Ops AX — Alert-Storm Load Testing and SQLite-to-PostgreSQL Migration

## 1. Load-test objectives

Use two complementary tests. **Locust** measures the complete HTTP path: connection handling, JSON parsing, authentication, FastAPI routing, SQLite contention, and response latency. **pytest-benchmark plus a threaded correctness test** measures the local policy-store path and makes it easier to isolate database overhead.

The target of 500 alerts/sec is a throughput target, not a guarantee that one Locust user can produce 500 requests/sec. If average response latency is 100 ms, at least 50 concurrent in-flight users are required by Little’s Law. A safer starting point is 250 users, each targeting approximately 2 requests/sec, then increase users if the server cannot maintain the target without queueing.

| Workload | Purpose | Recommended mix |
|---|---|---|
| Baseline | Establish healthy single-alert latency. | 100% distinct `cost_spike`; 60 seconds. |
| Duplicate storm | Validate idempotency and duplicate suppression. | 80% same IDs, 20% distinct. |
| Mixed incident storm | Exercise precedence and hot active-policy state. | 50% cost, 30% latency, 20% DLP. |
| Stale/replay storm | Verify rejection is cheap and safe. | 10% stale timestamps, 20% duplicate IDs. |
| Soak test | Detect WAL growth, memory growth, and cooldown leaks. | 300–500 alerts/sec for 15–30 minutes. |

## 2. Locust setup

The attached `load_tests/locustfile.py` targets the repository’s `/splunk/alert` endpoint. It sends the payload shape expected by the current webhook router: an outer `result` object containing `anomaly_type` and `metric_value`, plus `alert_id` and `timestamp` fields.

Install Locust in a separate test environment:

```bash
python -m pip install locust
```

Start the API in a test environment with a dedicated database file and test token:

```bash
export MCP_API_TOKEN=test-only-token
export POLICY_STATE_DB=/tmp/unified-ops-policy-test.db
python main.py --server
```

Run an approximate 500-alert/sec test:

```bash
mkdir -p results
locust -f load_tests/locustfile.py \
  --headless \
  --host http://127.0.0.1:8000 \
  -u 250 -r 250 \
  --run-time 60s \
  --csv results/alert_storm \
  --html results/alert_storm.html \
  --reset-stats
```

Set the token and workload mix when required:

```bash
MCP_API_TOKEN=test-only-token \
ALERTS_PER_USER_PER_SEC=2 \
ALERT_DUPLICATE_RATE=0.20 \
ALERT_STALE_RATE=0.05 \
locust -f load_tests/locustfile.py \
  --headless --host http://127.0.0.1:8000 \
  -u 250 -r 250 --run-time 60s \
  --csv results/alert_storm_mixed
```

The Locust file treats HTTP 409 and 429 as expected test signals, but the result report should still separate them from successful applications. For the current implementation, duplicate and precedence outcomes may be HTTP 200 JSON responses rather than 409 responses; add explicit status-code mapping in the FastAPI router before using HTTP response codes as an operational metric.

### Metrics to capture

Record request rate, failure rate, p50/p95/p99 response time, connection errors, HTTP 409/429 counts, policy-applied count, duplicate-rejected count, precedence-blocked count, audit-row count, SQLite busy/retry count, database size, WAL size, CPU, and memory. A useful acceptance report contains both the **offered rate** and the **achieved rate**. Do not claim 500 alerts/sec if Locust offered 500 but the server completed only 280.

A practical initial acceptance gate is: no unexpected 5xx responses, exactly one policy application for a duplicate storm, no lost audit records, no unbounded WAL growth during a soak test, and p95 latency that stays below the agreed operational budget. Choose the latency budget before testing; do not retrofit it to a favorable result.

## 3. pytest-benchmark and direct concurrency test

The attached `benchmarks/test_alert_storm_benchmark.py` provides two different signals. `test_single_alert_apply_latency` measures local policy transition latency using pytest-benchmark. `test_500_alert_storm_correctness` sends 500 distinct alerts through 32 threads and verifies the audit count. `test_duplicate_storm_accepts_exactly_one` verifies the most important idempotency invariant.

Run the correctness tests:

```bash
pytest -q benchmarks/test_alert_storm_benchmark.py
```

Run the benchmark separately:

```bash
pytest benchmarks/test_alert_storm_benchmark.py \
  --benchmark-only \
  --benchmark-min-rounds=20 \
  --benchmark-sort=mean
```

The direct benchmark is not a substitute for Locust. It does not include HTTP, serialization, authentication, or server scheduling. Use it to compare SQLite configurations such as rollback journal versus WAL, `synchronous=FULL` versus `NORMAL`, one connection per operation versus thread-local connections, and synchronous versus batched audit writes.

For a higher-fidelity rate test, run multiple repetitions and collect elapsed time from the threaded test. Compare `500 / elapsed_seconds` with the requested rate. Avoid a hard CI gate based on absolute alerts/sec because filesystem, CPU, and CI runner variability can be large. Use correctness as a hard gate and performance regression thresholds relative to a recorded baseline.

## 4. Migration strategy

The attached `scripts/migrate_policy_state.py` migrates the proposed policy-state tables: `processed_alerts`, `active_override`, and `audit_log`. It creates PostgreSQL tables, imports all rows in a single transaction, verifies row counts, and rolls back automatically if the import fails.

Install the PostgreSQL driver:

```bash
python -m pip install "psycopg[binary]>=3.1"
```

Perform a dry run first:

```bash
python scripts/migrate_policy_state.py \
  --sqlite data/policy_state.db \
  --postgresql "$DATABASE_URL" \
  --dry-run
```

Run the migration during a maintenance window or after stopping writes:

```bash
python scripts/migrate_policy_state.py \
  --sqlite data/policy_state.db \
  --postgresql "$DATABASE_URL"
```

The script is intentionally scoped to policy state. High-volume raw telemetry should not be copied into this database. Keep using Splunk or another event/analytics system for raw agent events, traces, and metrics.

## 5. Recommended zero-downtime cutover

A safe migration should use **expand, dual-write, backfill, verify, switch, contract** rather than changing the database URL in one deployment.

| Phase | Action | Exit criterion |
|---|---|---|
| Expand | Deploy PostgreSQL schema and a store interface with SQLite and PostgreSQL implementations. | Both adapters pass the same contract tests. |
| Dual-write | Keep SQLite as the read source, but write every new alert claim, override, and audit event to PostgreSQL as well. | Replication lag and write-error counters remain zero. |
| Backfill | Copy historical SQLite rows using the migration script. | Counts, checksums, and active override payload match. |
| Verify | Compare live reads from both stores for a sampled set of alert IDs and audit IDs. | No mismatches; PostgreSQL has required indexes. |
| Shadow-read | Read PostgreSQL in the background without using its result for decisions. | Stable read latency and no decoding/schema errors. |
| Cut over | Switch policy decisions to PostgreSQL using a feature flag. Keep SQLite dual-write for a rollback window. | Error rate and p95 remain within budget. |
| Contract | After the observation window, stop SQLite writes and archive the SQLite file. | Backup and restore drill succeeds. |

During dual-write, the PostgreSQL write must be idempotent. Use `alert_id` as the primary key and `ON CONFLICT DO NOTHING` for claims. For audit events, add a stable `event_id` or deterministic idempotency key; otherwise retries can duplicate audit rows.

Do not dual-write by opening a second unrelated transaction after the SQLite commit without recording whether the PostgreSQL write succeeded. Better options are an outbox table in SQLite or a small local event log that a retry worker drains into PostgreSQL. The outbox event should contain the operation type, stable event ID, payload, attempt count, and last error.

## 6. PostgreSQL schema and adapter contract

Use a narrow adapter interface so the rest of the application does not know whether the backend is SQLite or PostgreSQL:

```python
class PolicyStateStoreProtocol(Protocol):
    def claim_alert(self, alert_id: str, accepted_at: float) -> bool: ...
    def save_override(self, payload: dict, expires_at: float) -> None: ...
    def load_active_override(self, now: float) -> dict | None: ...
    def clear_override(self) -> None: ...
    def append_audit(self, event_type: str, event: dict, created_at: float) -> None: ...
    def audit_count(self) -> int: ...
```

The PostgreSQL implementation should use a connection pool, short transactions, parameterized queries, and an explicit unique constraint on `processed_alerts.alert_id`. For the active override, keep the singleton constraint or use a versioned row with optimistic concurrency control. For multiple policy scopes, use a composite key such as `(tenant_id, region, agent_pool)` instead of one global singleton.

## 7. Rollback plan

Keep the SQLite file untouched and writable during the rollback window. If PostgreSQL errors exceed the cutover threshold, flip the feature flag back to SQLite, stop PostgreSQL dual-write if it is causing cascading failures, and preserve failed outbox records for replay. Do not automatically copy PostgreSQL state back into SQLite during an incident; that can overwrite newer state. Instead, export the PostgreSQL rows created since the last verified checkpoint and reconcile them explicitly.

The rollback drill should test three cases: PostgreSQL unavailable, PostgreSQL slow but reachable, and a schema mismatch. The application should fail closed for high-impact remediation if it cannot durably record the policy intent. It may continue accepting low-risk telemetry through an asynchronous buffer, but it must not claim that a remediation succeeded when its durable state write failed.

## 8. Migration acceptance checklist

Before declaring the migration complete, verify that the same alert ID cannot be accepted twice across multiple application replicas; an active override survives process restart and database failover; rollback tokens remain valid; audit counts and sampled payload checksums match; old alert IDs are still rejected; stale webhook timestamps remain rejected; PostgreSQL backups can be restored into a clean instance; and the load test shows improved or stable p95/p99 latency at the target concurrency.

## References

[1]: https://www.sqlite.org/wal.html "SQLite Write-Ahead Logging"

[2]: https://www.sqlite.org/lang_transaction.html "SQLite Transactions"

[3]: https://www.postgresql.org/docs/current/sql-insert.html "PostgreSQL INSERT and ON CONFLICT"

[4]: https://docs.locust.io/en/stable/ "Locust documentation"

[5]: https://pytest-benchmark.readthedocs.io/en/latest/ "pytest-benchmark documentation"
