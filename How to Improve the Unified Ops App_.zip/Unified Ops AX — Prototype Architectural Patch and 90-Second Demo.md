# Unified Ops AX — Prototype Architectural Patch and 90-Second Demo

## 1. Recommended architectural fix

The repository already contains a first version of `DurablePolicyEngine`, including policy precedence, timestamp checks, idempotency, structured audit entries, and rollback tokens. The next highest-value fix is to make that state **durable and concurrency-safe across process restarts**.

Today, `active_override`, `processed_alert_ids`, and `audit_logs` are in-memory objects. The runtime path can therefore lose cooldowns, deduplication history, and audit evidence when the Streamlit/FastAPI process restarts. The engine also needs an explicit lock around the check-then-write sequence so two simultaneous alerts cannot both pass idempotency or overwrite the active policy inconsistently.

The prototype below keeps the current API but adds a small SQLite-backed state store. SQLite is appropriate for a hackathon prototype because it is local, transactional, and requires no additional service. In production, the same interface should be backed by Postgres, Redis, or a managed event store.

## 2. Prototype patch

### New file: `policy_state_store.py`

```python
from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path
from typing import Any, Optional


class PolicyStateStore:
    """Small transactional store for remediation state and audit evidence."""

    def __init__(self, path: str = "data/policy_state.db") -> None:
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=10000")
        return conn

    def _init_schema(self) -> None:
        with self._connect() as db:
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS processed_alerts (
                    alert_id TEXT PRIMARY KEY,
                    accepted_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS active_override (
                    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
                    payload_json TEXT NOT NULL,
                    expires_at REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    event_json TEXT NOT NULL,
                    created_at REAL NOT NULL
                );
                """
            )

    def claim_alert(self, alert_id: str, accepted_at: float) -> bool:
        """Atomically claim an alert ID; False means it was already processed."""
        with self._lock, self._connect() as db:
            try:
                db.execute(
                    "INSERT INTO processed_alerts(alert_id, accepted_at) VALUES (?, ?)",
                    (alert_id, accepted_at),
                )
                return True
            except sqlite3.IntegrityError:
                return False

    def save_override(self, payload: dict[str, Any], expires_at: float) -> None:
        with self._lock, self._connect() as db:
            db.execute(
                "INSERT INTO active_override(singleton, payload_json, expires_at) "
                "VALUES (1, ?, ?) ON CONFLICT(singleton) DO UPDATE SET "
                "payload_json=excluded.payload_json, expires_at=excluded.expires_at",
                (json.dumps(payload), expires_at),
            )

    def load_active_override(self, now: float) -> Optional[dict[str, Any]]:
        with self._lock, self._connect() as db:
            row = db.execute(
                "SELECT payload_json, expires_at FROM active_override WHERE singleton=1"
            ).fetchone()
            if not row:
                return None
            if row["expires_at"] <= now:
                db.execute("DELETE FROM active_override WHERE singleton=1")
                return None
            return json.loads(row["payload_json"])

    def clear_override(self) -> None:
        with self._lock, self._connect() as db:
            db.execute("DELETE FROM active_override WHERE singleton=1")

    def append_audit(self, event_type: str, event: dict[str, Any], created_at: float) -> None:
        with self._lock, self._connect() as db:
            db.execute(
                "INSERT INTO audit_log(event_type, event_json, created_at) VALUES (?, ?, ?)",
                (event_type, json.dumps(event), created_at),
            )

    def audit_count(self) -> int:
        with self._lock, self._connect() as db:
            return int(db.execute("SELECT COUNT(*) FROM audit_log").fetchone()[0])
```

### Changes to `auto_remediation.py`

The following is the minimal integration pattern. Keep the existing policy calculations and public response shape, but inject the store and make the critical sections atomic.

```diff
--- a/auto_remediation.py
+++ b/auto_remediation.py
@@
 import logging
 import os
+import threading
 import time
@@
 from typing import Any, Dict, List, Optional, Tuple
+from policy_state_store import PolicyStateStore
@@
-    def __init__(self, webhook_secret: str = "unified-ops-webhook-secret"):
+    def __init__(
+        self,
+        webhook_secret: str = "unified-ops-webhook-secret",
+        state_store: Optional[PolicyStateStore] = None,
+    ):
         self.webhook_secret = webhook_secret
-        self.active_override: Optional[PolicyOverrideState] = None
-        self.processed_alert_ids: set = set()
+        self.state_store = state_store or PolicyStateStore(
+            os.getenv("POLICY_STATE_DB", "data/policy_state.db")
+        )
+        self._lock = threading.RLock()
+        self.active_override: Optional[PolicyOverrideState] = None
+        self.processed_alert_ids: set = set()
         self.audit_logs: List[Dict[str, Any]] = []
@@
     def apply_remediation(...):
@@
-        # 1. Validate webhook & idempotency
-        valid, msg = self.validate_webhook(a_id, t_now)
-        if not valid:
-            logger.warning(f"[IDEMPOTENCY_REJECTED] {msg}")
-            return {...}
+        # 1. Validate timestamp and atomically claim the alert ID.
+        if abs(time.time() - t_now) > 300.0:
+            return {
+                "success": False,
+                "status": "rejected",
+                "reason": "Replay rejected: timestamp outside 300s window",
+                "alert_id": a_id,
+            }
+
+        with self._lock:
+            if not self.state_store.claim_alert(a_id, t_now):
+                return {
+                    "success": False,
+                    "status": "rejected",
+                    "reason": f"Idempotency rejected: alert_id {a_id} already processed",
+                    "alert_id": a_id,
+                }
@@
-        self.active_override = override
-        self.processed_alert_ids.add(a_id)
+        self.active_override = override
+        self.processed_alert_ids.add(a_id)
@@
         self.audit_logs.append(audit_entry)
+        self.state_store.save_override(
+            {
+                "override_id": override.override_id,
+                "owner": override.owner,
+                "version": override.version,
+                "applied_at": override.applied_at,
+                "expires_at": override.expires_at,
+                "anomaly_type": override.active_policy.anomaly_type.value,
+                "active_weights": override.active_weights,
+                "baseline_weights": override.baseline_weights,
+                "rollback_token": override.rollback_token,
+            },
+            override.expires_at,
+        )
+        self.state_store.append_audit("policy_applied", audit_entry, t_now)
@@
-        if not self.active_override:
+        with self._lock:
+            if not self.active_override:
+                return {"success": False, "reason": "No active policy override found"}
+
+            if self.active_override.rollback_token != rollback_token:
+                return {"success": False, "reason": "Invalid rollback token"}
+
+            prev_policy = self.active_override.active_policy.anomaly_type.value
+            self.active_override = None
+            self.state_store.clear_override()
+            self.state_store.append_audit(
+                "policy_rolled_back",
+                {"previous_policy": prev_policy},
+                time.time(),
+            )
+            logger.info(f"[POLICY_ROLLED_BACK] {prev_policy}")
+            return {
+                "success": True,
+                "status": "rolled_back",
+                "previous_policy": prev_policy,
+                "restored_weights": self.baseline_router_weights,
+            }
-            return {"success": False, "reason": "No active policy override found"}
-
-        if self.active_override.rollback_token != rollback_token:
-            return {"success": False, "reason": "Invalid rollback token"}
-
-        prev_policy = self.active_override.active_policy.anomaly_type.value
-        self.active_override = None
```

The diff is intentionally abbreviated around the existing policy-calculation block. The key invariant is that **alert claiming, precedence checking, override persistence, and audit persistence must be performed as one protected operation**. In a production version, move the transaction boundary into the store and use a database row lock or compare-and-swap operation so multiple application replicas share the same truth.

### Startup recovery

Add a recovery method that runs when the engine starts. It should load an unexpired override from the store and restore it into the in-memory router before accepting work.

```python
# in DurablePolicyEngine

def recover(self) -> None:
    payload = self.state_store.load_active_override(time.time())
    if not payload:
        return
    # Rehydrate only the runtime fields needed by routing and status endpoints.
    policy = self.policies[AnomalyType(payload["anomaly_type"])]
    self.active_override = PolicyOverrideState(
        active_policy=policy,
        override_id=payload["override_id"],
        owner=payload["owner"],
        version=payload["version"],
        applied_at=payload["applied_at"],
        expires_at=payload["expires_at"],
        baseline_weights=payload["baseline_weights"],
        active_weights=payload["active_weights"],
        rollback_token=payload["rollback_token"],
    )
```

Call `policy_engine.recover()` immediately after construction in `AsyncAgentEngine.__init__` or in the application startup hook. Do not rely on a daemon thread sleeping until expiry; the expiry timestamp is the source of truth.

## 3. Tests to add

Add tests for four failure modes: two threads submitting the same `alert_id`, process restart while an override is active, expiry recovery after cooldown, and rollback after restart. The minimum acceptance criteria are shown below.

| Test | Expected result |
|---|---|
| Duplicate alert from two concurrent callers | Exactly one `policy_applied`; the other receives `rejected`. |
| New engine instance using the same SQLite path | It recovers the active override and reports the same expiry and rollback token. |
| Expired override on startup | It is removed and the engine reports no active override. |
| Rollback after restart | The persisted token still rolls back the override and creates an audit record. |
| Lower-priority alert during critical override | It is precedence-blocked without changing the active override. |

## 4. Refined 90-second demo for hackathon judges

The unique value proposition should be stated as: **“Unified Ops AX closes the loop between observing AI-agent behavior and safely changing how the fleet operates.”** Do not lead with the map, the framework names, or the number of tabs. Lead with the operational outcome.

| Time | Screen/action | Spoken line | Judge takeaway |
|---:|---|---|---|
| 0–8s | Overview screen with DEMO badge, timestamp, and three KPIs. | “AI-agent fleets fail in three expensive ways: cost spikes, latency spikes, and sensitive data leaks. Unified Ops AX detects them and closes the loop.” | Clear problem and product category. |
| 8–20s | Show a normal fleet baseline: model mix, latency p95, spend, and regions. | “This is the baseline. We can see what the fleet is doing, which model is serving traffic, and how healthy the system is.” | Establishes observability before automation. |
| 20–35s | Trigger a cost-spike alert with a visible incident ID and affected model. | “Now the cost detector sees an abnormal hourly spend. Instead of sending a dashboard notification and waiting for an operator, the incident enters the remediation pipeline.” | Demonstrates event-driven behavior. |
| 35–50s | Open incident drawer: threshold, observed value, policy preview, proposed fallback, and expected trade-off. | “The system explains why it selected this policy: shift traffic toward a cheaper model, increase caching, and preserve a rollback path.” | Shows governed intelligence rather than opaque automation. |
| 50–65s | Click Approve or run an explicitly labelled Auto-Approved action. Show action timeline. | “The policy is applied, recorded, and time-bounded. Every action has an owner, version, cooldown, and audit entry.” | Differentiates safe remediation from a mere alerting dashboard. |
| 65–77s | Show before/after routing weights, cost estimate, and p95 latency. | “The important result is not that a function returned success. It is that fleet behavior changed, and we can verify the trade-off.” | Proves closed-loop impact. |
| 77–88s | Switch to DLP playground; inspect a payload containing SSN/card/API key. | “Before telemetry leaves the agent boundary, local DLP masking removes sensitive values and preserves an integrity signature.” | Adds security depth and reinforces the enterprise angle. |
| 88–90s | Return to Overview with incident resolved and one-line architecture overlay. | “Observe, protect, remediate, verify—that is Unified Ops AX.” | Leaves a memorable product loop. |

## 5. Demo refinements that matter most

First, use **one incident**, not several unrelated feature tours. A cost-spike incident is the best default because it is easy to understand, visually measurable, and naturally demonstrates routing, caching, policy state, and rollback. Use latency as a short variant only if the Kubernetes simulation is the judging criterion.

Second, put proof beside every claim. Show the incident ID, observed metric, threshold, policy version, and before/after values. If the app is simulated, say so in the UI and in the narration. Judges will reward a smaller, truthful system more than a larger-looking system that blurs the boundary between simulation and production integration.

Third, make the architecture visible only after the behavior is understood. A simple overlay should show **Agent Fleet → Telemetry → Detection → Policy → Remediation → Verification**. Framework names such as Google ADK, Splunk, Pub/Sub, and Gemini should appear as implementation detail, not as the opening message.

Finally, end with a differentiator sentence rather than a feature list: **“Most agent platforms can observe calls. Unified Ops AX uses those observations to safely change fleet behavior, prove the result, and leave an audit trail.”**

## 6. Implementation order

Implement the SQLite state store and locking first, then add startup recovery and concurrency tests. Next, refactor the Overview screen around the incident workflow and add explicit simulation/connectivity badges. Finally, instrument the demo with stable seed data, fixed timestamps, and deterministic before/after metrics so the 90-second recording is repeatable.

## References

[1]: https://github.com/sechan9999/unified-ops-ax "Unified Ops AX GitHub repository"

[2]: https://github.com/sechan9999/unified-ops-ax/blob/main/auto_remediation.py "Current DurablePolicyEngine implementation"

[3]: https://github.com/sechan9999/unified-ops-ax/blob/main/async_agent_engine.py "AsyncAgentEngine integration"
