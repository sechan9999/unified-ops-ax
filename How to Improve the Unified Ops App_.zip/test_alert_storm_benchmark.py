"""Microbenchmarks and correctness checks for the SQLite policy store.

Run:
  pytest -q benchmarks/test_alert_storm_benchmark.py
  pytest benchmarks/test_alert_storm_benchmark.py --benchmark-only \
    --benchmark-min-rounds=10

This benchmark exercises the policy engine directly. Use Locust for HTTP,
ASGI middleware, JSON parsing, authentication, and network measurements.
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import time

import pytest

from auto_remediation import AnomalyType, DurablePolicyEngine
from policy_state_store import PolicyStateStore


@pytest.fixture
def engine(tmp_path: Path) -> DurablePolicyEngine:
    return DurablePolicyEngine(
        state_store=PolicyStateStore(str(tmp_path / "benchmark.db"))
    )


def _apply_one(engine: DurablePolicyEngine, index: int) -> dict:
    return engine.apply_remediation(
        AnomalyType.COST_SPIKE,
        8.5,
        alert_id=f"bench-{index}",
        timestamp=time.time(),
    )


def test_single_alert_apply_latency(benchmark, engine):
    """Track local state-transition latency, excluding HTTP/network overhead."""
    result = benchmark(_apply_one, engine, 1)
    assert result["status"] in {"policy_applied", "precedence_blocked"}


def test_500_alert_storm_correctness(tmp_path: Path):
    """Send 500 distinct alerts concurrently and verify no duplicate audit rows."""
    store = PolicyStateStore(str(tmp_path / "storm.db"))
    engines = [DurablePolicyEngine(state_store=store) for _ in range(32)]

    started = time.perf_counter()
    with ThreadPoolExecutor(max_workers=32) as pool:
        results = list(
            pool.map(
                lambda i: _apply_one(engines[i % len(engines)], i),
                range(500),
            )
        )
    elapsed = time.perf_counter() - started

    accepted = sum(r["status"] == "policy_applied" for r in results)
    blocked = sum(r["status"] == "precedence_blocked" for r in results)
    assert accepted + blocked == 500
    assert store.audit_count() == accepted

    achieved_rate = 500 / elapsed
    print(f"500-alert direct-store rate: {achieved_rate:.1f} alerts/sec")
    # Do not make this an absolute CI gate; disk and CI runners vary widely.
    assert achieved_rate > 0


def test_duplicate_storm_accepts_exactly_one(tmp_path: Path):
    """A 500-request duplicate storm must produce one policy application."""
    store = PolicyStateStore(str(tmp_path / "duplicate-storm.db"))
    engines = [DurablePolicyEngine(state_store=store) for _ in range(32)]

    def submit(i: int) -> dict:
        return engines[i % len(engines)].apply_remediation(
            AnomalyType.COST_SPIKE,
            8.5,
            alert_id="same-alert-id",
            timestamp=time.time(),
        )

    with ThreadPoolExecutor(max_workers=32) as pool:
        results = list(pool.map(submit, range(500)))

    assert sum(r["status"] == "policy_applied" for r in results) == 1
    assert sum(r["status"] == "rejected" for r in results) == 499
    assert store.audit_count() == 1


def test_benchmark_is_repeatable(benchmark, tmp_path: Path):
    """Benchmark a small deterministic batch without reusing alert IDs."""
    counter = {"value": 0}
    store = PolicyStateStore(str(tmp_path / "repeatable.db"))
    engine = DurablePolicyEngine(state_store=store)

    def batch():
        index = counter["value"]
        counter["value"] += 1
        return _apply_one(engine, index)

    result = benchmark(batch)
    assert result["success"] is True
