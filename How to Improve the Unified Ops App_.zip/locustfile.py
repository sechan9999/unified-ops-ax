"""Locust workload for Unified Ops AX alert-storm testing.

Run a single-node 500 alerts/sec test:

  locust -f load_tests/locustfile.py --headless \
    -u 250 -r 250 --run-time 60s \
    --host http://127.0.0.1:8000 \
    --csv results/alert_storm

With 250 users and constant_throughput(2), the target is approximately
500 requests/sec when the server can sustain it. Increase users if p95 latency
approaches two seconds; Locust cannot create more requests than the users and
response latency allow.
"""

from __future__ import annotations

import itertools
import os
import random
import time
import uuid

from locust import HttpUser, between, task, constant_throughput


ANOMALIES = (
    ("cost_spike", 8.5),
    ("latency_spike", 6500.0),
    ("dlp_burst", 15.0),
)


def _bool_env(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).lower() in {"1", "true", "yes", "on"}


class AlertStormUser(HttpUser):
    """Generate valid, duplicate, and stale alert traffic."""

    # Set this to 2 for 250 users to target ~500 requests/sec.
    target_requests_per_user = float(os.getenv("ALERTS_PER_USER_PER_SEC", "2"))
    wait_time = constant_throughput(target_requests_per_user)

    # Set ALERT_DUPLICATE_RATE=0.20 to make 20% of traffic duplicate alert IDs.
    duplicate_rate = float(os.getenv("ALERT_DUPLICATE_RATE", "0.20"))
    stale_rate = float(os.getenv("ALERT_STALE_RATE", "0.00"))
    token = os.getenv("MCP_API_TOKEN", "")
    _duplicate_ids = tuple(
        f"storm-duplicate-{i}" for i in range(int(os.getenv("DUPLICATE_POOL", "100")))
    )
    _counter = itertools.count()

    def on_start(self):
        self.user_prefix = f"locust-{uuid.uuid4().hex[:10]}"

    @task
    def post_alert(self):
        anomaly_type, metric_value = random.choice(ANOMALIES)
        n = next(self._counter)

        if random.random() < self.duplicate_rate:
            alert_id = random.choice(self._duplicate_ids)
        else:
            alert_id = f"{self.user_prefix}-{n}"

        timestamp = time.time()
        if random.random() < self.stale_rate:
            timestamp -= 301

        payload = {
            "result": {
                "anomaly_type": anomaly_type,
                "metric_value": metric_value,
                "model": "gemini-3.5-flash",
                "session_id": self.user_prefix,
                "alert_id": alert_id,
                "timestamp": timestamp,
            },
            "search_name": "Unified Ops AX alert-storm benchmark",
            "alert_id": alert_id,
            "timestamp": timestamp,
        }
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["X-MCP-Token"] = self.token

        with self.client.post(
            "/splunk/alert",
            json=payload,
            headers=headers,
            name=f"POST /splunk/alert [{anomaly_type}]",
            catch_response=True,
        ) as response:
            if response.status_code in (200, 201, 202, 409, 429):
                # 409/429 should be counted separately in production dashboards,
                # but they are expected signals during a controlled storm test.
                response.success()
            else:
                response.failure(f"unexpected HTTP {response.status_code}: {response.text[:200]}")


class HealthProbeUser(HttpUser):
    """Low-rate health sampling; exclude this user when measuring pure webhook RPS."""

    wait_time = between(1, 2)
    weight = 0

    @task
    def health(self):
        self.client.get("/health", name="GET /health")
