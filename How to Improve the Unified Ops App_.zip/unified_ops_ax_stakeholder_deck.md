# Unified Ops AX — High-Concurrency Operations and Migration

## Cover
Unified Ops AX
High-Concurrency Alert Processing and Database Migration
Stakeholder briefing · August 2026

## Slide 1
### The operational problem is the feedback loop

AI-agent fleets generate fast-moving cost, latency, reliability, and data-protection incidents.

Most systems stop at observation: dashboards, alerts, and tickets.

Unified Ops AX is designed to close the loop: **observe → decide → remediate → verify**.

**Stakeholder question:** Can remediation remain safe and responsive when alerts arrive in a storm?

## Slide 2
### The architecture separates detection from action

**Ingress:** Splunk or monitoring systems send signed anomaly alerts to the webhook.

**Decision layer:** DurablePolicyEngine validates timestamps, deduplicates alerts, applies priority precedence, and creates a bounded policy override.

**Execution layer:** Workers execute remediation adapters for routing, caching, DLP escalation, and Kubernetes scaling.

**Evidence layer:** Every intent, action, verification result, rollback, and failure becomes an audit event.

Flow: **Alert ingress → atomic claim → policy decision → durable intent → async side effects → verification**

## Slide 3
### Alert storms create a single-writer pressure point

SQLite is a strong single-node prototype backend, but WAL mode still permits only one writer at a time.[1]

The hot path is not the dashboard; it is the sequence of alert claim, precedence check, override write, and audit write.

The design response is to keep transactions short, use atomic `INSERT ... ON CONFLICT`, avoid network calls inside transactions, and coalesce duplicate incidents.

**Key control:** one alert ID can produce at most one policy application, even across concurrent workers.

## Slide 4
### The load test validates both speed and correctness

**Locust workload:** 250 concurrent users × approximately 2 requests/user/second targets **~500 alerts/second** against `/splunk/alert`.

**Workload mix:** distinct alerts, duplicate storms, mixed cost/latency/DLP incidents, and stale/replayed timestamps.

**pytest-benchmark:** isolates local policy-transition latency from HTTP and network overhead.

**Hard correctness gates:** no unexpected 5xx responses; exactly one acceptance for a duplicate storm; no lost audit records; no unbounded WAL growth.

**Results status:** the harness is prepared and syntax-checked; a production benchmark run must populate achieved throughput and p50/p95/p99 results. No unmeasured performance number is presented as a fact.

## Slide 5
### The migration path preserves safety before speed

**Expand:** deploy PostgreSQL schema and a shared store interface.

**Dual-write:** keep SQLite as the decision source while PostgreSQL receives idempotent claims, overrides, and audit events.

**Backfill:** import historical SQLite state in one PostgreSQL transaction; verify counts and sampled checksums.

**Shadow-read:** compare PostgreSQL reads without using them for decisions.

**Cut over:** switch policy decisions behind a feature flag; retain SQLite fallback during an observation window.

**Contract:** archive SQLite only after backup, restore, and rollback drills pass.

## Slide 6
### PostgreSQL removes the single-node ceiling

SQLite remains appropriate for a single-host demo and early deployment.

PostgreSQL becomes the system of record when multiple application replicas, cross-host failover, high write volume, or long-lived audit retention are required.

The application should depend on a `PolicyStateStore` interface, not on SQLite-specific SQL.

PostgreSQL design principles: connection pooling, short transactions, unique alert IDs, idempotent writes, typed filter columns, and durable outbox processing for external side effects.[2]

## Slide 7
### The first production milestone is governable remediation

Expose a complete incident record: observed value, threshold, scope, policy version, owner, actions, cooldown, verification, and rollback token.

Separate **policy intent** from external side effects so a slow Slack, Splunk, or Kubernetes call cannot hold a database transaction open.

Add approval gates for high-impact actions and make simulation versus connected execution explicit in the UI.

Track the metrics that matter: accepted, deduplicated, precedence-blocked, failed, verified, and rolled-back remediations.

## Slide 8
### Decision and next steps

**Approve the load test:** run baseline, duplicate-storm, mixed-incident, replay, and 30-minute soak scenarios.

**Use correctness as the release gate:** one duplicate acceptance, durable audit, safe replay rejection, and restart recovery.

**Use measured latency to choose the migration point:** compare p50/p95/p99 and SQLite busy/retry rates at 500 alerts/second.

**Prepare PostgreSQL before the ceiling:** implement the adapter and dual-write path before the first multi-replica deployment.

**Outcome:** a control loop that is not only fast, but explainable, reversible, and auditable.

## Slide 9
### Sources and measurement notes

[1] SQLite documentation: WAL concurrency and checkpoint behavior.

[2] PostgreSQL documentation: `INSERT ... ON CONFLICT` for idempotent writes.

Locust target: 250 users × 2 requests/user/second ≈ 500 offered requests/second, subject to response latency and available concurrency.

Benchmark status: test code and migration utility were prepared; achieved Locust throughput and percentile latency require an actual run against the deployed test environment.

References:
[1] https://www.sqlite.org/wal.html
[2] https://www.postgresql.org/docs/current/sql-insert.html
